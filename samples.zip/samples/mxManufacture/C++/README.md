# C++ api sample

# 1 介绍
行业SDK流程编排C++ api的sample，该sample主要实现了从Sample.pipeline中读取pipeline创建推理stream，然后读取一张图片送到stream进行推理，获取推理结构后把结果打印出来，最后销毁stream。

# 2 配置（main.cpp所在的目录为当前目录）
## 2.1 获取模型
请确保pipeline所需要的yolov3和resnet50模型文件在`../models/yolov3`和`../models/resnet50`中存在，模型获取方法可参考《mxManufacture V100R020C20 用户指南》样例介绍->C++运行步骤章节的步骤1。
## 2.2 日志设置。
跳转到{sdk_install_path}/config目录，具体内容和配置参数参考日志配置logging.conf文件，根据需要修改其内容。日志参数配置完后，跳转到{sdk_install_path}/samples/mxManufacture/C++目录。
## 2.3 准备测试图片
准备一张图片（jpeg）进行推理，图片需要重命名为test.jpg并放在当前目录下。

# 3 运行
bash run.sh

# 4 提示
如果使用过程中遇到问题，请联系华为技术支持。 