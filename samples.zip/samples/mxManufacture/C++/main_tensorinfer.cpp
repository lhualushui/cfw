/*
 * Copyright (c) 2020.Huawei Technologies Co., Ltd. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <string>
#include "MxBase/Log/Log.h"
#include "MxBase/MemoryHelper/MemoryHelper.h"
#include "MxBase/Tensor/TensorBase/TensorBase.h"
#include "MxStream/StreamManager/MxStreamManager.h"
#include "MxTools/Proto/MxpiDataType.pb.h"

namespace {
const int INT32_BYTELEN = 4;
const int BERT_INPUT_NUM = 3;
}
using namespace std;
std::vector<std::string> Split(const std::string& inString, char delimiter)
{
    std::vector<std::string> result;
    if (inString.empty()) {
        return result;
    }

    std::string::size_type fast = 0;
    std::string::size_type slow = 0;
    while ((fast = inString.find_first_of(delimiter, slow)) != std::string::npos) {
        result.push_back(inString.substr(slow, fast - slow));
        slow = inString.find_first_not_of(delimiter, fast);
    }

    if (slow != std::string::npos) {
        result.push_back(inString.substr(slow, fast - slow));
    }

    return result;
}

std::string& Trim(std::string& str)
{
    str.erase(0, str.find_first_not_of(' '));
    str.erase(str.find_last_not_of(' ') + 1);

    return str;
}

std::vector<int32_t> SplitWithRemoveBlank(std::string& str, char rule)
{
    Trim(str);
    std::vector<std::string> strVec = Split(str, rule);
    for (size_t i = 0; i < strVec.size(); i++) {
        strVec[i] = Trim(strVec[i]);
    }
    std::vector<int32_t> res = {};
    for (size_t i = 0; i < strVec.size(); i++) {
        res.push_back(std::stoi(strVec[i]));
    }
    return res;
}

// This function is only for reading sample txt.
APP_ERROR SendEachProtobuf(int inPluginId, const std::string& filePath,
    std::shared_ptr<MxStream::MxStreamManager>& mxStreamManager, std::string& streamName)
{
    ifstream ifile(filePath);
    ostringstream buf;
    char ch;
    while (buf && ifile.get(ch)) {
        buf.put(ch);
    }
    std::string str = buf.str();
    auto vec = SplitWithRemoveBlank(str, ' ');
    auto dataSize = vec.size() * INT32_BYTELEN;
    auto dataPtr = &vec[0];

    MxBase::MemoryData memorySrc(dataPtr, dataSize, MxBase::MemoryData::MEMORY_HOST);
    MxBase::MemoryData memoryDst(dataSize, MxBase::MemoryData::MEMORY_HOST);
    APP_ERROR ret = MxBase::MemoryHelper::MxbsMallocAndCopy(memoryDst, memorySrc);
    if (ret != APP_ERR_OK) {
        LogError << "Fail to malloc and copy host memory.";
        return ret;
    }
    auto tensorPackageList = std::make_shared<MxTools::MxpiTensorPackageList>();
    auto tensorPackage = tensorPackageList->add_tensorpackagevec();
    auto tensorVec = tensorPackage->add_tensorvec();
    tensorVec->set_tensordataptr((uint64_t)memoryDst.ptrData);
    tensorVec->set_tensordatasize(dataSize);
    tensorVec->set_tensordatatype(MxBase::TENSOR_DTYPE_INT32);
    tensorVec->set_memtype(MxTools::MXPI_MEMORY_HOST_NEW);
    tensorVec->set_deviceid(0);
    tensorVec->add_tensorshape(1);
    tensorVec->add_tensorshape(vec.size());

    MxStream::MxstProtobufIn dataBuffer;
    ostringstream dataSource;
    dataSource << "appsrc" << inPluginId;
    dataBuffer.key = dataSource.str();
    dataBuffer.messagePtr = std::static_pointer_cast<google::protobuf::Message>(tensorPackageList);
    std::vector<MxStream::MxstProtobufIn> dataBufferVec;
    dataBufferVec.push_back(dataBuffer);

    ret = mxStreamManager->SendProtobuf(streamName, inPluginId, dataBufferVec);
    return ret;
}

std::string ReadPipelineConfig(std::string &pipelineConfigPath)
{
    std::ifstream file(pipelineConfigPath.c_str(), std::ifstream::binary);
    if (!file) {
        LogError << pipelineConfigPath <<" file is not exists";
        return "";
    }
    file.seekg(0, std::ifstream::end);
    uint32_t fileSize = file.tellg();
    file.seekg(0);
    std::unique_ptr<char[]> data(new char[fileSize]);
    file.read(data.get(), fileSize);
    file.close();
    std::string pipelineConfig(data.get(), fileSize);
    return pipelineConfig;
}

int main(int argc, char* argv[])
{
    std::string pipelineConfigPath = "../pipeline/BertMultiPorts.pipeline";
    std::string pipelineConfig = ReadPipelineConfig(pipelineConfigPath);
    if (pipelineConfig == "") {
        return APP_ERR_COMM_INIT_FAIL;
    }
    std::string streamName = "classification";

    auto mxStreamManager = std::make_shared<MxStream::MxStreamManager>();
    APP_ERROR ret = mxStreamManager->InitManager();
    if (ret != APP_ERR_OK) {
        LogError << GetError(ret) << "Failed to init Stream manager.";
        return ret;
    }
    ret = mxStreamManager->CreateMultipleStreams(pipelineConfig);
    if (ret != APP_ERR_OK) {
        LogError << GetError(ret) << "Failed to create Stream.";
        return ret;
    }
    std::vector<std::string> filePaths = {
            "./bert_input/ids_a_0.txt", "./bert_input/mask_a_0.txt", "./bert_input/segment_a_0.txt"
    };
    for (int i = 0; i < BERT_INPUT_NUM; i++) {
        SendEachProtobuf(i, filePaths[i], mxStreamManager, streamName);
    }

    std::vector<std::string> keyVec = {"mxpi_tensorinfer0", "mxpi_classpostprocessor0"};
    std::vector<MxStream::MxstProtobufOut> output = mxStreamManager->GetProtobuf(streamName, 0, keyVec);

    if (output.size() == 0) {
        LogError << "output size is 0";
        return APP_ERR_ACL_FAILURE;
    }
    if (output[0].errorCode != APP_ERR_OK) {
        LogError << "GetProtobuf error. errorCode=" << output[0].errorCode;
        return output[0].errorCode;
    }
    LogInfo << "errorCode=" << output[0].errorCode;
    LogInfo << "key=" << output[0].messageName;
    LogInfo << "value=" << output[0].messagePtr.get()->DebugString();

    if (output[1].errorCode != APP_ERR_OK) {
        LogError << "GetProtobuf error. errorCode=" << output[1].errorCode;
        return output[1].errorCode;
    }
    LogInfo << "errorCode=" << output[1].errorCode;
    LogInfo << "key=" << output[1].messageName;
    LogInfo << "value=" << output[1].messagePtr.get()->DebugString();
    mxStreamManager->DestroyAllStreams();

    return 0;
}