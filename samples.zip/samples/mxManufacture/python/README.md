# python api sample

## 介绍

行业SDK流程编排python api的sample，该sample主要实现了从sample.pipeline中读取pipeline创建推理stream，然后读取一张图片送到stream进行推理，获取推理结构后把结果打印出来，最后销毁stream。

## 配置

请确保pipeline所需要的yolov3和resnet50模型文件在`../models/yolov3`和`../models/resnet50`中存在，模型获取方法可参考《mxManufacture V100R020C20 用户指南》样例介绍->C++运行步骤章节的模型获取方法。

run.sh脚本中LD_LIBRARY_PATH设置了ACL动态库链接路径为/usr/local/Ascend/ascend-toolkit/latest/acllib/lib64，如果实际环境中路径不一致，需要替换为实际的目录。

准备一张图片（jpeg）进行推理，图片需要重命名为test.jpg并放在当前目录下。

## 运行

```bash
bash run.sh
```

如果使用过程中遇到问题，请联系华为技术支持。